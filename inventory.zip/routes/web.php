<?php

use App\Http\Controllers\BrandController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProductFeatureController;
use App\Http\Controllers\SupplierController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', [HomeController::class, 'index'])->middleware('check_status')->name('home');

//user
Route::get('/user/list', [HomeController::class, 'userList'])->name('user');
Route::get('/userDelete/{id}', [HomeController::class, 'userDelete'])->name('user.delete');
Route::get('/changeStatus', [HomeController::class, 'userChangeStatus']);
Route::get('/userEdit/{user_id}', [HomeController::class, 'userEdit'])->name('userEdit');
Route::get('/profile/change', [HomeController::class, 'profileChange'])->name('profile.change');
Route::post('/profile/name/update', [HomeController::class, 'nameChange']);
Route::post('/profile/password/update', [HomeController::class, 'passwordUpdate']);
Route::post('/profile/picture/update', [HomeController::class, 'picture_update']);
Route::post('user/profile/update', [HomeController::class, 'userUpdate'])->name('userUpdate');

//company
Route::get('/company', [CompanyController::class, 'index'])->name('company');
Route::get('/companyAdd', [CompanyController::class, 'companyAdd'])->name('companyAdd');
Route::post('/companyStore', [CompanyController::class, 'companyStore'])->name('companyStore');
Route::get('/companyEdit/{company_id}', [CompanyController::class, 'companyEdit'])->name('companyEdit');
Route::post('/companyUpdate', [CompanyController::class, 'companyUpdate'])->name('companyUpdate');
Route::post('/logoCompanyUpdate', [CompanyController::class, 'logoCompanyUpdate'])->name('logoCompanyUpdate');
Route::post('/mobilelogoCompanyUpdate', [CompanyController::class, 'mobilelogoCompanyUpdate'])->name('mobilelogoCompanyUpdate');
Route::post('/favIconCompanyUpdate', [CompanyController::class, 'favIconCompanyUpdate'])->name('favIconCompanyUpdate');
Route::get('/companyDelete/{id}', [CompanyController::class, 'companyDelete'])->name('companyDelete');



Route::get('product-feacture', [ProductFeatureController::class, 'index'])->name('product_feacture');
Route::get('product-feacture-add', [ProductFeatureController::class, 'product_feacture_add'])->name('product_feacture_add');
Route::post('product-feacture-store', [ProductFeatureController::class, 'productFeactureStore'])->name('productFeactureStore');
Route::get('product-feacture-edit/{product_feacture_id}', [ProductFeatureController::class, 'product_feacture_edit'])->name('product_feacture_edit');
Route::post('product-feacture-update', [ProductFeatureController::class, 'productFeactureUpdate'])->name('productFeactureUpdate');
Route::get('productFeactureDelete/{id}', [ProductFeatureController::class, 'productFeactureDelete'])->name('productFeactureDelete');



//supplier
Route::get('/supplier', [SupplierController::class, 'index'])->name('supplier');
Route::get('/supplierAdd', [SupplierController::class, 'supplierAdd'])->name('supplierAdd');
Route::post('/supplierStore', [SupplierController::class, 'supplierStore'])->name('supplierStore');
Route::get('/supplierEdit/{company_id}', [SupplierController::class, 'supplierEdit'])->name('supplierEdit');
Route::post('/supplierUpdate', [SupplierController::class, 'supplierUpdate'])->name('supplierUpdate');
Route::get('supplierDelete/{id}', [SupplierController::class, 'supplierDelete'])->name('supplierDelete');

//brand
Route::get('brand-name', [BrandController::class, 'index'])->name('brand');
Route::post('brand-name-store', [BrandController::class, 'store'])->name('brandNameStore');
Route::post('/brand-name-update', [BrandController::class, 'update'])->name('brandUpdate');
Route::get('/brandDelete/{id}', [BrandController::class, 'destroy'])->name('brandDelete');
