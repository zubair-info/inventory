
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>bitBirds - Dashboard</title>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description">
        <meta content="Coderthemes" name="author">
        <?php
            $get_company_info=App\Models\Company::first();
        ?>
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('/uploads/company')); ?>/<?php echo e($get_company_info->company_favicon); ?>">


         <!-- third party css -->
         <link href="<?php echo e(asset('backend/assets/css/vendor/jquery-jvectormap-1.2.2.css')); ?>" rel="stylesheet" type="text/css">
         <!-- third party css end -->
         <!-- App css -->
         <link href="<?php echo e(asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
         <link href="<?php echo e(asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
         <link href="<?php echo e(asset('backend/assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css">
        <link href="<?php echo e(asset('backend/assets/css/vendor/select.bootstrap5.css" rel="stylesheet')); ?>" type="text/css" />
        
         
<style>
    #basic-datatable_paginate{
        display: flex;
         justify-content: end;
    }
</style>
    </head>

    <body class="loading" data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
        <!-- Begin page -->
        <div class="wrapper">
            <!-- ========== Left Sidebar Start ========== -->
            <div class="leftside-menu">
    
                <!-- LOGO -->
                <a href="index.html" class="logo text-center logo-light">
                    <span class="logo-lg">
                        
                        
                        <img src="https://bitbirds.com/web/wp-content/uploads/2021/11/bitBirds-white-logo.png" alt="" height="30">
                    </span>
                    <span class="logo-sm">
                        <img  src="https://bitbirds.com/web/wp-content/uploads/2021/11/bitBirds-white-logo-300x77.png" alt="Logo" height="12">
                        
                    </span>
                </a>

                <!-- LOGO -->
                
                    
    
                <div class="h-100" id="leftside-menu-container" data-simplebar="">

                    <!--- Sidemenu -->
                    <ul class="side-nav">

                        

                        

                        <li class="side-nav-title side-nav-item">Admin</li>


                        <li class="side-nav-item">
                            <a href="<?php echo e(route('user')); ?>" class="side-nav-link">
                                <i class=" dripicons-user"></i>
                                <span>User</span>
                            </a>
                        <li class="side-nav-item">
                            <a href="<?php echo e(route('company')); ?>" class="side-nav-link">
                                <i class=" uil-copyright"></i>
                                <span>Setup Company</span>
                            </a>
                        </li>
                        <li class="side-nav-item">
                            <a href="<?php echo e(route('supplier')); ?>" class="side-nav-link">
                                <i class=" uil-copyright"></i>
                                <span>Supplier</span>
                            </a>
                        </li>
                        <li class="side-nav-item">
                            <a href="<?php echo e(route('product_feacture')); ?>" class="side-nav-link">
                                <i class="uil-comments-alt"></i>
                                <span>Product Feacture</span>
                            </a>
                        </li>

                        

                        

                    <!-- End Sidebar -->

                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->

            </div>
            <!-- Left Sidebar End -->

            <!-- ============================================================== -->
            <!-- Start Page Content here -->
            <!-- ============================================================== -->

            <div class="content-page">
                <div class="content">
                    <!-- Topbar Start -->
                    <div class="navbar-custom">
                        <ul class="list-unstyled topbar-menu float-end mb-0">
                            <li class="dropdown notification-list d-lg-none">
                                <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <i class="dripicons-search noti-icon"></i>
                                </a>
                                <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
                                    <form class="p-3">
                                        <input type="text" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
                                    </form>
                                </div>
                            </li>
                            

                            

                                    <!-- item-->
                                    

                                    

                                    <!-- All-->
                                    

                                
                            

                            

                            

                            <li class="dropdown notification-list">
                                <a class="nav-link dropdown-toggle nav-user arrow-none me-0" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <span class="account-user-avatar"> 
                                        <img  src="<?php echo e(asset('/uploads/users')); ?>/<?php echo e(Auth::user()->profile_photo); ?>" alt="user-image" class="rounded-circle">
                                    </span>
                                    <span>
                                        <span class="account-user-name"><?php echo e(Auth::user()->name); ?></span>
                                        <span class="account-position">Founder</span>
                                    </span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated topbar-dropdown-menu profile-dropdown">
                                    <!-- item-->
                                    <a href="<?php echo e(route('profile.change')); ?>" class="dropdown-item notify-item">
                                        <i class="mdi mdi-account-circle me-1"></i>
                                        <span>My Account</span>
                                    </a>

                                    <!-- item-->
                                    

                                    <!-- item-->
                                    <a class="dropdown-item notify-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"> <i class="mdi mdi-logout me-1"></i>
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                    
                                </div>
                            </li>

                        </ul>
                        <button class="button-menu-mobile open-left">
                            <i class="mdi mdi-menu"></i>
                        </button>
                        <div class="app-search dropdown d-none d-lg-block">
                            

                            
                        </div>
                    </div>
                    <!-- end Topbar -->

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        
                        <?php echo $__env->yieldContent('content'); ?>
                        <!-- end page title --> 
                        
                    </div> <!-- container -->

                </div> <!-- content -->

                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-6">
                                <script>document.write(new Date().getFullYear())</script> © bitBirds - bitbirds.com
                            </div>
                            
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->

            </div>

            <!-- ============================================================== -->
            <!-- End Page content -->
            <!-- ============================================================== -->


        </div>
        <!-- END wrapper -->


        <!-- Right Sidebar -->
        

        <div class="rightbar-overlay"></div>
        <!-- /End-bar -->


        <!-- demo app -->
        
        <!-- end demo js-->
        
        <script src="<?php echo e(asset('backend/assets/js/vendor.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/app.min.js')); ?>"></script>
 
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
        <script>
			<?php if(Session::has('message')): ?>
				var type ="<?php echo e(Session::get('alert-type', 'info')); ?>"
				switch(type){
				case 'info':
				toastr.info(" <?php echo e(Session::get('message')); ?> ");
				break;
			
				case 'success':
				toastr.success(" <?php echo e(Session::get('message')); ?> ");
				break;
			
				case 'warning':
				toastr.warning(" <?php echo e(Session::get('message')); ?> ");
				break;
			
				case 'error':
				toastr.error(" <?php echo e(Session::get('message')); ?> ");
				break;
				}
			<?php endif; ?>
		</script>

        <!-- plugin js -->
        <script src="<?php echo e(asset('backend/assets/js/vendor/dropzone.min.js')); ?>"></script>
        <!-- init js -->
        <script src="<?php echo e(asset('backend/assets/js/ui/component.fileupload.js')); ?>"></script>
        <!-- third party js -->
        <!-- third party js -->
        <script src="<?php echo e(asset('backend/assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/responsive.bootstrap5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/buttons.bootstrap5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/buttons.html5.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/buttons.flash.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/buttons.print.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/dataTables.keyTable.min.js')); ?>"></script>
        <script src="<?php echo e(asset('backend/assets/js/vendor/dataTables.select.min.js')); ?>"></script>
        <!-- third party js ends -->

        <!-- demo app -->
        <script src="<?php echo e(asset('backend/assets/js/pages/demo.datatable-init.js')); ?>"></script>
        <!-- end demo js-->
        <?php echo $__env->yieldContent('footer_script'); ?>
        
    </body>
</html>
<?php /**PATH D:\inventory\inventory\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>