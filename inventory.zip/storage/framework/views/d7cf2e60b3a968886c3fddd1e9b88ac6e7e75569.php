
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);">bitbirds</a></li>
                    
                    <li class="breadcrumb-item active">Profile</li>
                </ol>
            </div>
            <h4 class="page-title">Profile Update</h4>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xl-4 col-lg-5">
        <div class="card text-center">
            <div class="card-body">
                <img src="<?php echo e(asset('/uploads/users')); ?>/<?php echo e(Auth::user()->profile_photo); ?>" class="rounded-circle avatar-lg img-thumbnail" alt="profile-image">

                <h4 class="mb-0 mt-2 text-capitalize"><?php echo e(Auth::user()->name); ?></h4>
                <p class="text-muted font-14">Founder</p>
                <div class="text-start mt-3">
                    
                    

                    <p class="text-muted mb-2 font-13"><strong>Mobile :</strong><span class="ms-1"><?php echo e(Auth::user()->phone); ?></span></p>

                    <p class="text-muted mb-2 font-13"><strong>Email :</strong> <span class="ms-1 "><?php echo e(Auth::user()->email); ?></span></p>

                    <p class="text-muted mb-1 font-13"><strong>Location :</strong> <span class="ms-1"><?php echo e(Auth::user()->address); ?></span></p>
                </div>
            </div> <!-- end card-body -->
        </div> <!-- end card -->


    </div> <!-- end col-->

    <div class="col-xl-8 col-lg-7">
        <div class="card">
            <div class="card-body">
                <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                    <li class="nav-item">
                        <a href="#aboutme" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0 active">
                            About
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#timeline" data-bs-toggle="tab" aria-expanded="true" class="nav-link rounded-0">
                            Password
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#settings" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                            Profile Picture
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane" id="aboutme">

                        <h5 class="mb-4 text-uppercase"><i class="mdi mdi-account-circle me-1"></i> Personal Info Update</h5>
                        <form action="<?php echo e(url('/profile/name/update')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-4">
                                <label for="" class="form-label"> Name</label>
    
                                <input type="text" name="name" class="form-control" value="<?php echo e(Auth::user()->name); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
                            </div>
                            <div class="mb-3">
                                <label for="phone" class="form-label"> Phone</label>
                                <input type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>"  id="phone" class="form-control" placeholder="Enter  phone">
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" name="email"   value="<?php echo e(Auth::user()->email); ?>"  class="form-control disabled"  placeholder="Enter email">
                            </div>
                            <div class="mb-3">
                                <label for="address" class="form-label">Address</label>
                                <input type="text" name="address"  value="<?php echo e(Auth::user()->address); ?>"  class="form-control" placeholder="Enter  address">
                            </div>
                    
                            <div class="text-end">
                                <button type="submit" class="btn btn-success mt-2"><i class="mdi mdi-content-save"></i> Update</button>
                            </div>
                        </form>
                    </div> <!-- end tab-pane -->
                    <!-- end about me section content -->

                    <div class="tab-pane show active" id="timeline">
                        <form action="<?php echo e(url('/profile/password/update')); ?> " method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-4">
                                <label for="old_password" class="form-label">Old Password</label>
    
                                <input type="password" name="old_password" id="old_password" class="form-control">
                                <?php if(session('wrong_pass')): ?>
                                    <strong class="text-danger mt-2"> <?php echo e(session('wrong_pass')); ?> </strong>
                                <?php endif; ?>
    
                                <?php if(session('same_pass')): ?>
                                    <strong class="text-danger mt-2"> <?php echo e(session('same_pass')); ?> </strong>
                                <?php endif; ?>
                                <?php $__errorArgs = ['old_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
    
    
                            </div>
                            <div class="form-group mb-4">
                                <label for="password" class="form-label">New Password</label>
    
                                <input type="password" id="password" name="password" class="form-control">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
                            </div>
                            <div class="form-group mb-4">
                                <label for="password_confirmation" class="form-label">Confirm Password</label>
    
                                <input type="password" name="password_confirmation" id="password_confirmation"
                                    class="form-control">
                                <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    
                            </div>
                   

                        <div class="text-end">
                            <button type="submit" class="btn btn-success mt-2"><i class="mdi mdi-content-save"></i> Update</button>
                        </div>
                    </form>

                    </div>
                    <!-- end timeline content-->

                    <div class="tab-pane" id="settings">
                        <h5 class="mb-4 text-uppercase"><i class="mdi mdi-account-circle me-1"></i>Profile Picture Change</h5>
                        <form action="<?php echo e(url('/profile/picture/update')); ?> " method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="custom-file mb-4">
                                <label class="">Choose file</label>
                                <input type="file" name="profile_photo" class="form-control">
                                
                                <?php $__errorArgs = ['profile_photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <img src="<?php echo e(asset('/uploads/users')); ?>/<?php echo e(Auth::user()->profile_photo); ?>" alt="table-user" height="90" class="mt-1" />
                            </div>
                        
                            <div class="text-end">
                                <button type="submit" class="btn btn-success mt-2"><i class="mdi mdi-content-save"></i> Update</button>
                            </div>
                        </form>
                    </div>
                    <!-- end settings content-->

                </div> <!-- end tab-content -->
            </div> <!-- end card body -->
        </div> <!-- end card -->
    </div> <!-- end col -->
</div>
<!-- end row-->

</div>
<!-- container -->

</div>
<!-- content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\inventory\inventory\resources\views/admin/user/profile.blade.php ENDPATH**/ ?>